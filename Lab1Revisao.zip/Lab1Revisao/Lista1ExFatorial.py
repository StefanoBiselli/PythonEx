f = int(input("digite um numero para saber seu fatorial "))
cont = f-1
if f == 0:
    print(1)
else:
    while cont > 0:
        f = f*cont
        cont = cont - 1
    print(f)