numero = int(input("Digite um numero para saver a soma de seus digitos "))
print(sum(int(digit) for digit in str(numero)))