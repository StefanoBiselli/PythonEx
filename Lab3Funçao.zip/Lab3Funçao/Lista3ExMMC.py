def mmc(num1,num2):
    if num1 > num2:
        maior = num1
    else:
        maior = num2
    while True:
        if maior % num1 == 0 and maior % num2 == 0:
            return maior
            break
        else:
            maior = maior + 1

num1, num2 = int(input("Digite um número inteiro: ")), int(input("Digite outro número inteiro: "))
print("O mínimo multiplo comum é:", mmc(num1,num2))