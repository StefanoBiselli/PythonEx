def decimal(x):
    exp = 0
    soma = 0
    for i in x:
        soma += int(i) * 2 ** exp
        exp += 1
    return soma

dec = str(input("digite um numero na base binaria "))
x = dec[::-1]
print('A conversão do binario:',dec,'para decimal é: ',decimal(x))